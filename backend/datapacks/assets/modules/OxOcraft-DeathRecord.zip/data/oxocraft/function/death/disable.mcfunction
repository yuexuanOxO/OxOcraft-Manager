scoreboard players set death_record oxo_feature 0
data modify storage oxocraft:system modules.death_record.enabled set value 0
