# OxOcraft Death Record Module v1.0.1
scoreboard objectives add oxo_deaths deathCount
scoreboard objectives add oxo_death_event dummy
data modify storage oxocraft:system modules.death_record.version set value "1.0.1"
data modify storage oxocraft:system modules.death_record.enabled set value 0
data modify storage oxocraft:system modules.death_record.event_code set value "OXO_DEATH_RECORDED"
