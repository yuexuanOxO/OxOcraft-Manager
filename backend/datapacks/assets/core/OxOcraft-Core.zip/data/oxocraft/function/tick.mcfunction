# OxOcraft-Manager datapack tick entrypoint
function oxocraft:death/tick
