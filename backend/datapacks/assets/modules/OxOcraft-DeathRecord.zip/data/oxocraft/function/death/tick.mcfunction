# Run death record detector only when feature flag is enabled
execute if score death_record oxo_feature matches 1 as @a[scores={oxo_deaths=1..}] run function oxocraft:death/detect
