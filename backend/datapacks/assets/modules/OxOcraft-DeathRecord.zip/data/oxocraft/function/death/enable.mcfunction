scoreboard players set death_record oxo_feature 1
data modify storage oxocraft:system modules.death_record.enabled set value 1
