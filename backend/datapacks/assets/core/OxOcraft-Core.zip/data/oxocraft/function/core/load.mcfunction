# OxOcraft-Manager Core v1.0.0
scoreboard objectives add oxo_feature dummy
scoreboard players set death_record oxo_feature 0
data modify storage oxocraft:system core_version set value "1.0.0"
data modify storage oxocraft:system datapack_name set value "OxOcraft-Manager"
