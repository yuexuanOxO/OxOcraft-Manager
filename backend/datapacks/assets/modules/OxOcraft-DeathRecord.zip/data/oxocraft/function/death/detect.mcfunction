# @s is the player whose oxo_deaths score increased
# Player-visible message uses Chinese. Backend should read oxo_death_event as the stable event counter.
scoreboard players set @s oxo_death_event 1
tellraw @s {"text":"<OxO> 死亡資訊已紀錄","color":"dark_aqua"}
scoreboard players reset @s oxo_deaths
