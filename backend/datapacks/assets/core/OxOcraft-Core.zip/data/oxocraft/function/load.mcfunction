# OxOcraft-Manager datapack entrypoint
function oxocraft:core/load
function oxocraft:death/load
